import { ChangeBgDirective } from './change-bg.directive';

describe('ChangeBgDirective', () => {
  it('should create an instance', () => {
    const directive = new ChangeBgDirective();
    expect(directive).toBeTruthy();
  });
});
